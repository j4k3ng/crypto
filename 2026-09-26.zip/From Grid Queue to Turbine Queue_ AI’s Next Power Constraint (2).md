# From Grid Queue to Turbine Queue: AI’s Next Power Constraint

*Data center developers are turning to new gas generation to solve a time-to-power problem. But constrained turbine supply is creating a second queue — one that can become the critical path once a project chooses gas.*

U.S. data center electricity demand is accelerating just as the infrastructure needed to serve it is running into longer development timelines. Lawrence Berkeley National Laboratory’s June 2026 reference case puts U.S. data center electricity consumption at 649 TWh in 2030, up from roughly 176 TWh in 2023 — an increase from about 20 GW to 74 GW of equivalent average load.

For developers, however, the problem is not simply whether enough electricity exists nationally. Large data centers need hundreds of megawatts, sometimes more than a gigawatt, at a specific location and on a specific schedule. That has made **time to power** one of the defining constraints on new development.

For projects that cannot secure grid power quickly, new gas-fired generation is one of the most practical sources of dispatchable capacity available this decade. But that route now has a constraint of its own.

## From Grid Queue to Turbine Queue

Berkeley Lab’s 2026 *Speed to Power* report found that growth from data centers and other large loads is already creating connection bottlenecks. New generation also faces long timelines: projects reaching commercial operation in 2025 had spent a median of more than five years between interconnection request and operation in regions with available data.

Gas is attractive because it can add dispatchable capacity at scale. Berkeley Lab counted 253 GW of natural gas capacity in U.S. generator interconnection queues at the end of 2025, up 86% during the year.

But a gas plant is only a fast solution if its critical equipment is available.

GE Vernova reported 116 GW of Gas Power equipment backlog and slot reservation agreements in Q2 2026, up from 100 GW in the prior quarter. GE is on track to reach a 20 GW annualized gas-turbine output rate in Q3 2026, with 24 GW targeted in 2028 and 30 GW in 2030.

The 116 GW position is equivalent to 5.8 times GE’s targeted Q3 2026 annualized output rate. That should not be interpreted as a 5.8-year waiting list: the figure combines backlog and slot reservations across different delivery years and configurations. It does, however, show how large committed demand has become relative to current manufacturing throughput.

The constraint extends beyond GE. Siemens Energy is investing $1 billion to expand U.S. manufacturing, while Mitsubishi Heavy Industries reported a contractual backlog of 80 large-frame gas turbines, representing 35 GW, after Q1 FY2026.

## Project Behavior Is Already Changing

The clearest signal is that developers are securing equipment earlier.

NRG Energy announced in February 2025 a development agreement with GE Vernova and Kiewit for up to 5.4 GW of new combined-cycle generation, initially reserving 1.2 GW of GE 7HA turbine capacity. By 2026, NRG said turbine capacity and EPC had been secured for the full 5.4 GW program, with the first 1.2 GW expected online in 2029.

Homer City in Pennsylvania offers another example. The redevelopment of the former coal station is planned around up to 4.4 GW of gas generation using seven GE Vernova turbines while also taking advantage of infrastructure at an existing power site.

Both projects show how long lead times are pushing developers to secure scarce equipment and infrastructure earlier in the development process.

## What to Watch

The key question is whether turbine supply can expand fast enough to keep pace with the next wave of gas-fired generation. Actual OEM shipments and delivery windows will matter more than headline backlog alone.

At the same time, a growing use of brownfield sites, existing generation or alternative modular technologies would be a sign that developers are redesigning projects around turbine availability.

Developers looking to escape the grid queue may simply find themselves entering the turbine queue.