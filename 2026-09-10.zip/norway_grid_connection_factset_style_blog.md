# Norway Has Plenty of Power. The Scarce Asset Is Becoming a Grid Connection

**Category:** Energy Market Insight  
**Suggested length:** short blog / market note  
**Suggested dek:** Data centres, industrial electrification and national-security needs are testing Norway’s hydro advantage. The next competition may be less about electricity supply in aggregate and more about who gets connected to the grid.

---

Norway generated a record amount of electricity in 2025. It also entered 2026 with one of the strongest renewable power systems in Europe: a hydro-dominated fleet, roughly 87 TWh of reservoir storage and a long-standing reputation for flexible, low-carbon electricity.

Yet the most interesting recent development in Norway’s power market is not another hydropower record. It is the grid queue.

In late August, Statnett reported that it had connected more than 600 MW of new electricity consumption over the previous 12 months. During the first half of 2026 alone, however, the transmission operator received mature grid-connection applications totalling around 3.5 GW, an increase of about 2.0 GW compared with the same period in 2025. In the same update, Statnett noted that it had introduced stricter maturity requirements for being placed in the queue and reserving capacity.

That is a strong signal about where scarcity is emerging. Norway may still have a positive national power balance, but new demand does not consume electricity at the national average. A data centre, defence facility, hydrogen project or industrial expansion needs capacity at a specific grid node, at a specific time, under specific connection terms.

The scarce asset is increasingly not power in the abstract. It is **grid access**.

## Data centres are the clearest stress test

NVE updated its data-centre analysis in August 2026, stating that Norwegian data centres consumed 3.3 TWh of electricity in 2025, roughly double the level in 2023. NVE also describes data centres as the fastest-growing electricity-consuming sector in Norway over the past two years and a “joker” in the power balance toward 2030.

The queue numbers are even more striking. In NVE’s 2026 report on the status and development of the Norwegian power system, data-centre projects with reserved or queued capacity in the transmission grid total roughly 10 GW. At an assumed 70% utilisation rate, that would correspond to around 60 TWh per year if fully realised.

That figure should not be read as a forecast. NVE is clear that many planned projects depend on new grid construction, and much of that grid is unlikely to be completed before 2030. Not all data-centre projects will be built, and not all reserved or queued capacity will turn into actual load.

But the queue itself matters. It shows the scale of prospective demand trying to secure access to a system that was largely built around a different industrial geography and a different pace of load growth.

## The hydro advantage is real, but it is locational

Norway’s power system remains exceptional. In 2025, Statistics Norway reported 161.8 TWh of electricity production, with hydropower accounting for nearly 90% of the total. The country’s reservoir system gives producers the ability to shift generation across time, making Norwegian hydro more flexible than most renewable resources.

That flexibility is economically valuable, especially in a European system with increasing wind and solar volatility. Reservoir operators can generate when domestic demand is high, save water for tighter periods, or respond to prices in connected markets.

However, that flexibility is not equally available everywhere inside Norway. The country is divided into five electricity bidding zones because internal transmission constraints matter. In the third quarter of 2025, NVE reported average wholesale prices of roughly 69 EUR/MWh in NO2, compared with about 3 EUR/MWh in NO4, using a common EUR/NOK conversion convention. The most expensive zone was therefore more than 20 times the cheapest.

That spread is the market’s way of saying that national abundance is not enough. Power has to reach the right region.

## Queue management is becoming part of energy policy

The clearest sign that the issue has moved beyond ordinary market pricing is legal and regulatory.

In 2026, Norway adopted changes to the Energy Act allowing the King in Council, in exceptional cases, to order priority grid connection or capacity increases for a specific electricity-consuming customer when necessary for national security interests. Stortinget’s committee noted that the threshold for using the authority is high and that it applies only when necessary to protect national security interests.

On September 7, the Ministry of Energy opened a consultation on related tariff-regulation changes. The proposal would require grid companies to repay investigation costs and construction contributions to actors affected when another customer is prioritised for national-security reasons.

This is not a general mechanism for politicians to choose winners across the economy. It is limited to exceptional national-security cases. Still, the direction is important. Norway is creating rules for what happens when one customer’s urgent grid need can affect another customer’s reservation or queue position.

That is what a scarce connection queue looks like.

## More wires, smarter wires

Norway is not standing still. Statnett is both building new grid infrastructure and extracting more capacity from the existing system.

The long-term physical build-out includes a stronger 420 kV backbone, new substations and reinforcements across key north–south corridors. At the same time, Statnett is using faster operational measures such as temperature uprating, flow-based market coupling and automated balancing. In its August update, Statnett said it added around 1,000 MW of capacity to the existing grid in 2025 and up to 1,200 MW more in the first half of 2026, mainly through temperature uprating. It also said flow-based market coupling had made up to 700 MW of additional capacity available between northern and southern Norway and Sweden in some situations.

These measures help. But they do not remove the underlying challenge. New grid infrastructure takes years, while large-load connection requests can arrive much faster.

## Why this matters for investors and industry

The investment question in Norway is shifting. Historically, the country’s appeal was clear: renewable electricity, flexible hydropower, political stability and a cold climate. That combination is particularly attractive to data centres and other power-intensive users.

The emerging question is different:

> Can a project secure grid capacity in the right place on the right timeline?

For data centres, this may become more important than the national average power price. For industrial projects, it can determine whether electrification or expansion is feasible. For grid operators and policymakers, it forces a more explicit balancing of economic development, regional prices, security priorities and the pace of infrastructure investment.

Norway is not running out of water. It is running into coordination constraints. The country’s next power-market story will be about how fast it can scale energy, peak power and transmission — and how it decides who gets access while the system catches up.

---

# Source notes

- Statistics Norway / SSB — Electricity statistics: https://www.ssb.no/en/energi-og-industri/energi/statistikk/elektrisitet/
- SSB — Highest electricity production ever, 2025 article: https://www.ssb.no/energi-og-industri/energi/statistikk/elektrisitet/artikler/hoyeste-stromproduksjon-noensinne-05052026
- NVE — Energy use in data centres: https://www.nve.no/energi/energisystem/energibruk/energibruk-i-datasenter/
- NVE — Status og utvikling i kraftsystemet 2025–2030, Report 17/2026: https://publikasjoner.nve.no/rapport/2026/rapport2026_17.pdf
- NVE — Power situation Q3 2025: https://www.nve.no/media/19384/kraftsituasjonen_2025q3.pdf
- Statnett — Half-Year Report 2026: https://www.statnett.no/en/about-statnett/news-and-press-releases/news-archive-2026/half-year-report-2026-statnett-sf---increasing-the-pace-of-grid-development/
- Statnett — System Development Plan 2025 summary: https://www.statnett.no/globalassets/for-aktorer-i-kraftsystemet/planer-og-analyser/sup/summary-of-system-development-plan-2025.pdf
- Norwegian Ministry of Energy — Prop. 49 L (2025–2026): https://www.regjeringen.no/no/dokumenter/prop.-49-l-20252026/id3153126/
- Stortinget — Innst. 383 L (2025–2026): https://www.stortinget.no/no/Saker-og-publikasjoner/Publikasjoner/Innstillinger/Stortinget/2025-2026/inns-202526-383l/?all=true
- Lovdata — Energy Act amendment, 19 June 2026: https://lovdata.no/lov/2026-06-19-37
- Norwegian Ministry of Energy — 7 Sept. 2026 consultation: https://www.regjeringen.no/no/dokumenter/horing-av-endringer-i-forskrift-for-omsetningskonsesjonarer-om-tilbakebetaling-av-anleggsbidrag-ved-prioriteringsvedtak-av-hensyn-til-nasjonale-sikkerhetsinteresser/id3171987/

---

# Notes on FactSet-style fit

This draft follows the observed FactSet Energy Insight structure:

- starts with a current market development;
- provides quantitative context early;
- uses short analytical sections with clear headings;
- avoids academic footnotes in the main text;
- ends with an investment / market-structure implication rather than a policy recommendation.
