# Norway Power Story — 15-Minute Presentation, Updated

**Goal:** 15 minutes, 7 slides, one sharp storyline.

**Updated thesis:** Norway is not running out of water. It is running into a new scarcity: **grid access**. The country's hydro advantage now depends on whether Norway can scale **energy, power, wires and connection rights** together.

**Narrative arc:**
1. Norway looks abundant.
2. Hydro makes it flexible.
3. But flexibility is geographically trapped.
4. Data centres and new industry are turning grid access into the scarce resource.
5. Norway is building and optimising the grid.
6. Demand growth means more generation is also needed.
7. The strategic question is coordination: energy + power + wires + access.

---

## Slide 1 — Hook: The Scarce Asset Is a Grid Connection

**Time:** ~2:00

### Title
**Norway Has Plenty of Power. The Scarce Asset Is a Grid Connection.**

### On-slide message
- 2025 electricity production: **161.8 TWh**
- Hydro share: **89.9%**
- Reservoir storage: **87.4 TWh**
- First half 2026: **3.5 GW** mature grid-connection applications
- Previous 12 months: **600+ MW** new consumption connected

### Graphic
A Norway map with:
- five bidding zones;
- hydro-rich regions;
- north–south transmission bottlenecks;
- a queue of new loads waiting at the grid edge.

Visual headline on map:
**“Abundant nationally. Constrained at the point of connection.”**

### Voiceover
“Norway is often described as Europe’s green battery. But the most recent data changes the story. In 2025, Norway produced a record 161.8 TWh of electricity, almost 90% from hydro. Yet by 2026, Statnett was receiving grid-connection requests much faster than new consumption was actually being connected. The scarce asset is increasingly not electricity in the abstract. It is permission and physical ability to connect to the grid in a specific place.”

### Sources
SSB; NVE; Statnett Half-Year Report 2026.

---

## Slide 2 — Portfolio: Hydro Dominates, but Output Depends on Water

**Time:** ~2:00

### Title
**Capacity Barely Moved. Output Did.**

### On-slide message
| | 2021 | 2025 |
|---|---:|---:|
| Hydro capacity | 34.1 GW | 34.7 GW |
| Hydro generation | 143.7 TWh | 145.5 TWh |

Add one highlighted point:
**2022 hydro generation: 128.7 TWh**

### Graphic
Two visuals:
1. 2025 generation-mix donut: hydro dominates.
2. Hydro-generation line, 2021–2025, highlighting 2022 and 2025.

### Voiceover
“The Norwegian power system is still overwhelmingly hydro-based. But hydro output is not fixed by installed capacity. Capacity barely moved from 2021 to 2025, while generation moved sharply. The 2022 low and 2025 high show the role of hydrology: precipitation, snowmelt, inflows and reservoir management. Norway’s first constraint is therefore water, not just megawatts.”

### Sources
SSB Electricity Statistics; SSB 2025 production article.

---

## Slide 3 — Energy vs Power: The Battery Analogy

**Time:** ~2:00

### Title
**The Hydro Opportunity May Be Power, Not Just Energy**

### On-slide message
- Reservoir storage: **87.4 TWh**
- Normal annual hydro production: **~138 TWh/year**
- Installed hydro capacity: **34.7 GW**
- Hydro upgrades: **+5–6 TWh/year**, but **~+7 GW**
- Including pumped storage: toward **~+14 GW** power potential

### Graphic
Layered battery diagram:
- Storage = reservoir TWh
- Energy = annual production
- Power = peak GW

Add callout:
**“More output in the critical hour.”**

### Voiceover
“The word battery is useful only if we split it into pieces. Storage, annual energy and instantaneous power are different. Norway may not add huge amounts of new hydro energy, but it can add significant peak capacity. That means the country can make the battery stronger, not just bigger — producing more electricity exactly when demand or prices are highest.”

### Sources
NVE Hydropower Overview; NVE Hydropower Potential.

---

## Slide 4 — One Country, Five Markets

**Time:** ~2:15

### Title
**Abundance in Aggregate. Scarcity Locally.**

### On-slide message
Q3 2025 wholesale prices, **EUR/MWh**:
- NO1: **53.5**
- NO2: **69.3**
- NO3: **9.6**
- NO4: **3.1**
- NO5: **31.6**

Highlight:
**NO2 was more than 20× NO4**

### Graphic
Heat map of Norway's five bidding zones with price labels.

Add one simple arrow:
**Surplus power → bottleneck → higher-price region**

### Voiceover
“This is the central paradox. Norway is one country, but it is five electricity bidding zones. In Q3 2025, the average wholesale price in southwest Norway was about 69 EUR/MWh. In northern Norway it was about 3 EUR/MWh. That is more than a twenty-fold spread. Norway can therefore be abundant nationally and scarce locally at the same time.”

### Sources
NVE Power Situation Q3 2025; Statnett bidding-zone material.

---

## Slide 5 — The Live Stress Test: Data Centres and the Queue

**Time:** ~2:30

### Title
**AI and Data Centres Turn Grid Access Into the Bottleneck**

### On-slide message
- Data-centre consumption: **3.3 TWh in 2025**
- Roughly doubled from 2023
- NVE calls data centres a **“joker”** in the 2030 power balance
- Transmission-grid data-centre queue / reservations: **~10 GW**
- At 70% utilisation, that equals **~60 TWh/year** if fully realised

### Graphic
Funnel visual:
**Plans → reserved / queued grid capacity → projects requiring new grid → actual connected load**

Add warning badge:
**“Not all projects will be built — but the queue itself is the signal.”**

### Voiceover
“This is the most topical slide. Data centres used only 3.3 TWh in 2025, but demand is growing quickly. NVE says data centres are a joker in the power balance toward 2030. Even more striking, data-centre projects with reserved or queued transmission capacity total around 10 GW, equivalent to around 60 TWh per year at 70% utilisation if fully realised. NVE does not expect all of this to materialise, because many projects depend on new grid. But that is exactly the point: the constraint is access.”

### Sources
NVE Data Centre page; NVE Report 17/2026.

---

## Slide 6 — Norway’s Response: More Wires, Smarter Wires, New Rules

**Time:** ~2:15

### Title
**The Grid Is Becoming a Managed Scarcity**

### On-slide message
**Physical build-out**
- 420 kV backbone
- North–south reinforcements
- New substations

**Operational optimisation**
- Temperature uprating
- Flow-based market coupling
- Automated balancing

**Allocation rules**
- Stricter maturity requirements
- Priority connection possible in exceptional national-security cases

### Key numbers
- **271** active grid projects by H1 2026
- **~1,000 MW** extra capacity added in 2025
- **up to ~1,200 MW** more in H1 2026
- **118** temperature-uprating projects planned

### Graphic
Three-lane road visual:
1. Build
2. Optimise
3. Prioritise

### Voiceover
“Norway’s response has three layers. First, build more grid: 420 kV lines, substations and stronger corridors. Second, use the existing grid better through uprating and smarter flow calculation. Third, manage access more actively. Statnett has tightened maturity rules for the connection queue, and Norway has introduced a legal mechanism to prioritise certain grid connections in exceptional national-security cases. That is a strong signal: grid access has become scarce enough to require allocation rules.”

### Sources
Statnett Half-Year Report 2026; Statnett System Development Plan 2025; Prop. 49 L; Stortinget; Ministry consultation 7 Sept. 2026.

---

## Slide 7 — Strategic Close: Energy + Power + Wires + Access

**Time:** ~2:00

### Title
**Can Norway Scale the Whole System Together?**

### On-slide message
NVE expects toward 2030:
- normal-year power balance narrows to **~4 TWh**
- power balance narrows to **~1.2 GW**
- little new production before 2030

Long-term new supply by 2050:
- Hydro: **~+10 TWh**
- Onshore wind: **~+17 TWh**
- Offshore wind: **~+17 TWh**
- Solar: **~+10 TWh**

### Graphic
Four-part framework:
- **Energy** — enough annual TWh
- **Power** — enough peak GW
- **Wires** — enough transmission
- **Access** — who gets connected first

In the centre:
**Norway’s power advantage**

### Voiceover
“The forward question is no longer just whether Norway has enough hydropower. It is whether Norway can expand energy, peak power, transmission and access rules together. The country has a strong starting point, but demand is growing before most new generation arrives. If Norway coordinates the system well, flexible hydro remains a major advantage. If it does not, Norway can remain abundant in aggregate while becoming constrained exactly where new demand wants to locate.”

### Closing line
**“Norway is not running out of water. It is running into coordination constraints.”**

### Sources
NVE Report 17/2026; NVE Long-Term Power Market Analysis 2025; NVE Hydropower Potential; Statnett.

---

# Timing plan

| Slide | Approx. time |
|---|---:|
| 1. Hook / grid access | 2:00 |
| 2. Portfolio / hydrology | 2:00 |
| 3. Hydro energy vs power | 2:00 |
| 4. Five markets / price spread | 2:15 |
| 5. Data centres / queue | 2:30 |
| 6. Grid response / new rules | 2:15 |
| 7. Strategic close | 2:00 |
| **Total** | **~15:00** |

---

# What to leave for Q&A / appendix

Keep these out of the main 15 minutes unless asked:

- full 2021–2025 capacity and generation tables;
- Eurostat household-price methodology;
- detailed Norgespris mechanics;
- every Statnett line project;
- exact breakdown of the 20 TWh hydro potential;
- detailed offshore-wind policy vs forecast discussion;
- detailed legal language of Energy Act §3-8.

---

# Best single-sentence thesis

**Norway’s power advantage is no longer just about having flexible hydro; it is about allocating scarce grid access while demand from data centres, electrification and strategic industry accelerates.**
