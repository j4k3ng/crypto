# Norway Power Story — Verified Main Report

*Abundant hydro. Constrained access. A system that now needs both more wires and more generation.*

**Verification note — updated 10 September 2026.** This report uses official or institutional sources only: Statistics Norway (SSB), NVE/RME, Statnett, the Norwegian Government/Ministry of Energy, Eurostat and the official Norwegian Energy Facts portal. Recent 2026 developments have been added from NVE, Statnett, the Norwegian Ministry of Energy, Lovdata and Stortinget.

**Price convention.** All electricity prices are shown in **EUR/MWh**. NOK/øre power prices are converted using **EUR 1 = NOK 11.4**, the exchange-rate convention used in relevant Norwegian Ministry of Energy / NVE analytical material. The conversions are for analytical comparability, not transaction-level historical FX matching.

---

## Executive thesis

Norway is not simply a country with cheap renewable power. It is a country with a large, flexible hydro system whose value depends on **location, timing and access to the grid**.

The old story was: Norway has abundant hydropower.

The updated story is sharper:

> **Norway has abundant flexible power, but the scarce asset is increasingly the ability to connect and deliver it.**

Three constraints now define the system:

1. **Energy** — enough annual TWh.
2. **Power** — enough flexible GW in peak hours.
3. **Wires** — enough transmission and connection capacity in the right place.

The 2026 update makes this thesis more urgent. NVE now describes data centres as a major uncertainty for the 2030 power balance, with Norwegian data-centre consumption doubling from 2023 to 2025. Statnett says the connection queue is growing rapidly, with 3.5 GW of mature grid-connection applications received in the first half of 2026. Norway has also introduced a legal mechanism allowing priority grid connection in exceptional national-security cases, and the Ministry of Energy opened a consultation on how to compensate parties displaced by such prioritisation.

The question is no longer only whether Norway has enough electricity. It is **who gets access to scarce grid capacity, where and when**.

---

## 1. A hydro-dominated power system

Norway has one of Europe's most renewable electricity systems, built overwhelmingly around hydropower. In 2025, the country had **41.25 GW** of installed generation capacity and produced **161.8 TWh** of electricity, the highest level in the current SSB series.

Hydropower generated **145.5 TWh**, or **89.9%** of total output. Wind supplied **13.9 TWh**, thermal generation **2.1 TWh** and solar **0.35 TWh**.

But Norway's defining feature is not just that it is renewable. It is **flexible**. Norway has roughly **1,100 hydropower reservoirs** with about **87.4 TWh** of energy storage, and more than **75%** of Norwegian production capacity is flexible.

That makes the hydro system resemble an enormous battery. The analogy is useful, but incomplete. Norway's “battery” has three different constraints:

- **Water** determines how much energy is available.
- **Turbines and waterways** determine how much power can be produced at a given moment.
- **The grid** determines where that power can actually go.

---

## 2. Portfolio: capacity moved less than production

### Installed capacity by technology, GW

| Technology | 2021 | 2022 | 2023 | 2024 | 2025 |
|---|---:|---:|---:|---:|---:|
| Hydro | 34.075 | 34.269 | 34.291 | 34.549 | **34.666** |
| Wind | 5.049 | 5.062 | 5.064 | 5.063 | **5.063** |
| Solar | 0.155 | 0.301 | 0.619 | 0.790 | **0.918** |
| Thermal | 0.979 | 0.845 | 0.565 | 0.572 | **0.600** |
| **Total** | **40.257** | **40.476** | **40.538** | **40.975** | **41.247** |

### Actual electricity generation by technology, TWh

| Technology | 2021 | 2022 | 2023 | 2024 | 2025 |
|---|---:|---:|---:|---:|---:|
| Hydro | 143.699 | 128.749 | 137.315 | 139.984 | **145.476** |
| Wind | 11.768 | 14.810 | 13.965 | 14.545 | **13.899** |
| Solar | 0.033 | 0.063 | 0.165 | 0.251 | **0.348** |
| Thermal | 1.612 | 2.319 | 2.528 | 2.357 | **2.070** |
| **Total** | **157.113** | **145.942** | **153.973** | **157.136** | **161.793** |

The contrast matters. Installed hydro capacity rose by only about **1.7%** between 2021 and 2025, while actual hydro generation moved by almost **17 TWh** between the low-output year of 2022 and 2025.

That is a large change in output without a large change in installed megawatts. The reason is hydrology: precipitation, snowmelt, inflows and reservoir management.

**Capacity barely moved; output did.**

---

## 3. How big is the hydro battery?

There is no single meaningful number called “the maximum annual amount of hydroelectricity Norway can extract.” A reservoir system is continuously replenished by inflows. Annual generation can therefore exceed the amount stored in reservoirs at any one point, and it can also exceed normal annual production in wet years.

| Metric | Approximate level | Meaning |
|---|---:|---|
| Installed hydro capacity | **34.7 GW** | How much hydro generation capacity exists |
| Reservoir storage | **87.4 TWh** | How much energy can be stored in reservoirs |
| Normal annual hydro production | **~138 TWh/year** | Expected output under normal hydrological conditions |
| 2025 actual hydro generation | **145.5 TWh** | Actual output in a strong hydro year |
| Remaining technical-economic hydro potential | **~20 TWh/year** | Undeveloped potential before full real-world constraints |

NVE estimates roughly **20 TWh/year** of remaining technical-economic hydropower potential: about **14 TWh** from small hydro and **6 TWh** from larger projects. However, NVE explicitly distinguishes this from realistic buildable potential. Environmental constraints, social acceptance, economics and grid capacity mean the amount actually developed is likely lower.

---

## 4. The hidden hydro opportunity: power, not just energy

The more interesting hydro opportunity may be increasing **power capacity** rather than annual energy production.

NVE estimates that upgrades and expansions of existing hydropower plants could provide approximately:

- **5–6 TWh/year** of additional generation; and
- around **7 GW** of additional power capacity.

Including pumped-storage projects, the estimated additional power potential rises toward **14 GW**, even though net annual electricity production would increase much less and could even decline slightly because pumping consumes electricity.

This distinction is strategic. A project that adds turbine capacity without adding much annual energy can still be valuable if it lets Norway produce much more electricity during a cold winter evening, a low-wind period or a high-price hour.

> **Norway can increase the power of its hydro battery more than it can increase the energy stored inside it.**

---

## 5. Three scarcity questions

Norway's system faces three separate adequacy questions:

1. **Energy adequacy:** does the country have enough electricity over a year?
2. **Power adequacy:** is enough generation capacity available during the highest-demand hours?
3. **Grid adequacy:** can the system transport electricity to the region where demand is located?

Reservoirs help with the first two. Transmission determines the third.

That is why national abundance can coexist with local scarcity.

---

## 6. The price paradox: cheap country, expensive places

Eurostat's comparable household benchmark for consumers using 2,500–4,999 kWh/year was approximately **EUR 192/MWh** in the second half of 2025, including energy, network charges, taxes and levies. This is a retail household benchmark, not a wholesale spot price and not a typical annual household bill.

From October 2025, households could choose **Norgespris**, a government price-protection scheme. Under the FX convention used here, the standard reference price is about **EUR 43.9/MWh including VAT** through the end of 2026. Network tariffs, taxes and supplier mark-ups still apply separately.

These figures should not be compared one-for-one. Eurostat is an all-in retail benchmark. Norgespris stabilises the electricity-price component.

The more important market signal is the regional wholesale spread.

---

## 7. One country, five power markets

Norway is divided into five electricity bidding zones: **NO1, NO2, NO3, NO4 and NO5**. The zones exist because transmission capacity between regions is finite. When there is enough transfer capacity, prices tend to converge. When a bottleneck binds, the country economically splits.

### Average wholesale prices, Q3 2025, EUR/MWh

| Zone | Region | Average price |
|---|---|---:|
| NO1 | Southeast | **53.5** |
| NO2 | Southwest | **69.3** |
| NO3 | Central | **9.6** |
| NO4 | North | **3.1** |
| NO5 | West | **31.6** |

The most expensive Norwegian zone was therefore more than **20 times** as expensive as the cheapest during the quarter.

NVE's Q3 2025 report explains the split through a combination of strong hydrology and high reservoir levels in the north, weaker hydrology in the south, and transmission constraints that limited the ability to move surplus electricity toward higher-price areas.

That is the central paradox:

> **Norway can be abundant nationally and scarce locally at the same time.**

---

## 8. 2026 update: the grid queue becomes the story

The most recent developments shift the story from price differences to **grid access allocation**.

Statnett reported on 27 August 2026 that it had connected more than **600 MW** of new electricity consumption over the previous 12 months. But in the first half of 2026 alone it received mature grid-connection applications totalling around **3.5 GW**, about **2.0 GW** more than in the same period the previous year.

That comparison is not a formal backlog metric, but it captures the pressure on the system:

> **new demand is requesting grid access much faster than new consumption is being connected.**

Statnett also introduced stricter maturity requirements in 2026 for being placed in the queue and reserving capacity. This matters because grid capacity is no longer merely a technical constraint. It is becoming an economic allocation problem.

---

## 9. Data centres are the live stress test

NVE updated its data-centre page on 26 August 2026. Norwegian data centres consumed **3.3 TWh** of electricity in 2025, roughly double the level in 2023. NVE describes data centres as the fastest-growing electricity-consuming sector in Norway over the previous two years and refers to them as a **“joker”** in the power balance toward 2030.

NVE's 2026 system-status report provides the sharper number: data-centre projects with reserved or queued capacity in the transmission grid total about **10 GW**. At an assumed 70% utilisation rate, that would correspond to roughly **60 TWh/year** of electricity consumption if fully realised.

That does not mean 60 TWh of data-centre demand will actually materialise. Many projects depend on new grid construction; NVE expects much of that grid not to be completed by 2030. NVE therefore says available grid capacity is likely to be the limiting factor for data-centre growth — more than power prices.

This is the clearest example of Norway's new problem. Data centres are attracted by renewable power, relatively low prices, cold climate and political stability. But what they need is not “Norway's annual TWh.” They need firm access to hundreds of MW at a specific node.

---

## 10. A legal signal: grid access can now be prioritised

Norway has also changed the legal framework for grid access.

Prop. 49 L (2025–2026) proposed a new provision in the Energy Act allowing the King in Council, in exceptional cases, to order priority grid connection or capacity increases for a specific electricity-consuming customer when necessary for national security interests. The proposal was motivated by the changed security-policy situation and the need to support defence industry and critical societal functions.

Stortinget's committee described the threshold as high and noted that the rule can only be used when necessary for national security interests. The adopted law was published by Lovdata as the 19 June 2026 amendment to the Energy Act.

On 7 September 2026, the Ministry of Energy opened a consultation on related tariff-regulation changes. The proposal would require grid companies to refund investigation costs and construction contributions to actors affected when another customer is prioritised for national-security reasons. In other words, the government is now designing rules for what happens when priority access displaces someone else's grid reservation or queue position.

This does not mean the government will routinely choose between data centres, factories and households. The power is limited to exceptional national-security cases. But the existence of the mechanism is a clear signal:

> **grid connection capacity has become scarce enough to require explicit allocation rules.**

---

## 11. Norway is attacking the grid bottleneck

Statnett is pursuing two strategies simultaneously:

1. **build a stronger transmission backbone**, and
2. **extract more usable capacity from the existing grid**.

The structural upgrade centres on stronger **420 kV** infrastructure. Projects include the Sogndal–Aurland line, Blåfalli–Gismarvik, Surna–Viklandet, Skaidi–Hammerfest, Skaidi–Lebesby and new substations around major load centres.

The faster operational work includes temperature uprating, Dynamic Line Rating, flow-based market coupling, automated balancing and flexible connection agreements.

Statnett reported:

- **248** active development projects at end-2025;
- **271** active grid projects by mid-2026;
- approximately **1,000 MW** of extra capacity added to the existing grid in 2025;
- up to **1,200 MW** more added in the first half of 2026, mainly through temperature uprating;
- **118** temperature-uprating projects planned, with **58** under way;
- up to **700 MW** of additional capacity in some situations from flow-based market coupling.

The strategy is:

> **more lines + higher-voltage lines + higher utilisation of existing lines + smarter system operation.**

---

## 12. But transmission alone will not be enough

NVE's 2026 status report says Norway had a historically high power surplus in 2025: **23 TWh** in the actual weather year, and around **15 TWh** in a normal year. The country also had a positive power balance of about **2.6 GW** and good ability to cover its own consumption in the tightest hours.

But both balances are expected to weaken toward 2030. NVE now expects the normal-year power balance to fall to about **4 TWh** by 2030 and the power balance to decline to around **1.2 GW**. Consumption is expected to grow faster than production, driven especially by data centres and electrification, while little new generation is expected before 2030.

This updates the older long-term narrative. Norway is not expected simply to “run out” of electricity, but its margin is shrinking, and shrinking margins make the system more exposed to hydrology, import availability and regional grid constraints.

---

## 13. Where will new electricity come from?

Longer-term, NVE expects total electricity production to increase by roughly **49 TWh** between 2023 and 2050. The central additions come from a diversified renewable mix:

| Source | Approximate increase by 2050 |
|---|---:|
| Onshore wind | **+17 TWh** |
| Offshore wind | **+17 TWh** |
| Solar | **+10 TWh** |
| Hydro | **+10 TWh** |

Hydro remains the backbone and the main source of dispatchable flexibility. Onshore wind can add large volumes but faces permitting and local-acceptance constraints. Offshore wind is slower and more expensive but can add significant volume after 2030. Solar grows quickly from a very small base.

Policy ambition must be separated from base-case forecast. The government's ambition to allocate offshore areas with potential for **30 GW** by 2040 is not the same as assuming 30 GW will be installed and operating by then.

---

## 14. Final framing

Norway's electricity advantage is changing.

Historically, the story was abundant low-carbon hydropower.

Today, the immediate problem is often **location**: surplus electricity in one region cannot always reach another region at the right time.

The 2026 update adds a second layer: **connection rights**. Data centres, industry, electrification projects and national-security needs increasingly compete for scarce grid access.

The forward question is therefore:

> **Can Norway scale energy, power and wires together — and allocate scarce grid access without undermining its industrial advantage?**

---

## TL;DR

Norway's edge is not simply cheap renewable electricity. It is flexible renewable electricity.

The country has a large hydro system, around **87.4 TWh** of reservoir storage and a highly flexible generation fleet. But the value of that flexibility depends on where it can be delivered.

Regional price spreads show the physical constraint. In Q3 2025, the most expensive Norwegian bidding zone was more than **20 times** as expensive as the cheapest.

The 2026 data-centre and grid-queue updates show that the constraint is now becoming an allocation issue. Norway is receiving large volumes of grid-connection applications, especially from data centres, at the same time as the country has created a legal mechanism to prioritise certain grid connections for national-security reasons.

The next Norwegian power story is therefore not just about water. It is about **energy, power, wires and access rights**.

---

# Source list

1. Statistics Norway / SSB — Electricity statistics: https://www.ssb.no/en/energi-og-industri/energi/statistikk/elektrisitet/
2. SSB — Highest electricity production ever, 2025 article: https://www.ssb.no/energi-og-industri/energi/statistikk/elektrisitet/artikler/hoyeste-stromproduksjon-noensinne-05052026
3. NVE — Updated reservoir storage capacity: https://www.nve.no/nytt-fra-nve/nyheter-energi/oppdaterte-tall-for-magasinkapasitet-i-norge/
4. Norwegian Energy Facts — Electricity production: https://energifaktanorge.no/en/norsk-energiforsyning/kraftproduksjon/
5. NVE — Hydropower overview: https://www.nve.no/energi/energisystem/vannkraft/
6. NVE — Hydropower potential overview: https://www.nve.no/energi/energisystem/vannkraft/oversikt-over-vannkraft/
7. Eurostat — Household electricity prices, nrg_pc_204: https://ec.europa.eu/eurostat/en/web/products-datasets/-/NRG_PC_204
8. NVE/RME — Norgespris: https://www.nve.no/reguleringsmyndigheten/kunde/stroem/dette-er-norgespris/
9. Statnett — Bidding zones and congestion revenues: https://www.statnett.no/en/for-stakeholders-in-the-power-industry/tariffs/congestion-revenues/
10. NVE — Power situation Q3 2025: https://www.nve.no/media/19384/kraftsituasjonen_2025q3.pdf
11. NVE — Status og utvikling i kraftsystemet 2025–2030, Report 17/2026: https://publikasjoner.nve.no/rapport/2026/rapport2026_17.pdf
12. NVE — Energy use in data centres: https://www.nve.no/energi/energisystem/energibruk/energibruk-i-datasenter/
13. Statnett — Half-Year Report 2026: https://www.statnett.no/en/about-statnett/news-and-press-releases/news-archive-2026/half-year-report-2026-statnett-sf---increasing-the-pace-of-grid-development/
14. Statnett — System Development Plan 2025 summary: https://www.statnett.no/globalassets/for-aktorer-i-kraftsystemet/planer-og-analyser/sup/summary-of-system-development-plan-2025.pdf
15. Norwegian Ministry of Energy — Prop. 49 L (2025–2026): https://www.regjeringen.no/no/dokumenter/prop.-49-l-20252026/id3153126/
16. Stortinget — Innst. 383 L (2025–2026): https://www.stortinget.no/no/Saker-og-publikasjoner/Publikasjoner/Innstillinger/Stortinget/2025-2026/inns-202526-383l/?all=true
17. Lovdata — Energy Act amendment, 19 June 2026: https://lovdata.no/lov/2026-06-19-37
18. Norwegian Ministry of Energy — 7 Sept. 2026 consultation on repayment after prioritisation decisions: https://www.regjeringen.no/no/dokumenter/horing-av-endringer-i-forskrift-for-omsetningskonsesjonarer-om-tilbakebetaling-av-anleggsbidrag-ved-prioriteringsvedtak-av-hensyn-til-nasjonale-sikkerhetsinteresser/id3171987/
19. NVE — Long-term Power Market Analysis 2025: https://www.nve.no/energi/analyser-og-statistikk/langsiktig-kraftmarkedsanalyse/langsiktig-kraftmarkedsanalyse-2025/
20. Norwegian Government — Offshore wind policy: https://www.regjeringen.no/no/tema/naringsliv/gront-industriloft/havvind/id2920295/
